import React from 'react';

export const idee_monument = {
    id_monument: {
        id: 0,
    },
};

export const Context = React.createContext(
    idee_monument.id_monument
)
